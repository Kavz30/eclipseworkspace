package com.bt.ms.im.ngpos.dbclient.entity.dto;

import org.springframework.beans.factory.annotation.Value;

public interface GetDlrAccCtgDto {
	
	@Value("#{target.atAccountCategory}")
	
	String getatAccountCategory();

}
