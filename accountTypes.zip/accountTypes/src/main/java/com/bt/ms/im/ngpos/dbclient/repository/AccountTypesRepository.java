package com.bt.ms.im.ngpos.dbclient.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bt.ms.im.ngpos.dbclient.entity.AccountTypes;

import com.bt.ms.im.ngpos.dbclient.entity.dto.GetDlrAccCtgDto;



@Transactional(timeout=3)
@Repository

public interface AccountTypesRepository  extends JpaRepository<AccountTypes, String>{

	
	
	List<GetDlrAccCtgDto> findDlrAccCtgDtoByAtAccountType(String accountType);
	
	
}
