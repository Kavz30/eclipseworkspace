package com.bt.ms.im.ngpos.dbclient.entity.dto;

import org.springframework.beans.factory.annotation.Value;

public interface GetDealerDetailsDto {
	
	@Value("#{target.dealerGroup}")
	String getdealerGroup();
	
	@Value("#{target.branchCodeInd}")
	String getbranchCodeInd();

}
