package com.bt.ms.im.ngpos.dbclient.entity.dto;

import org.springframework.beans.factory.annotation.Value;

public interface GetDealerGroupsInfoDto {
	
	@Value("#{target.webSecFlg}")

	String getwebSecFlg();
	
	@Value("#{target.dctRoute}")
	
	String getdctRoute();
	
	@Value("#{target.webPasswd}")
	
	String getwebPasswd();
	
	@Value("#{target.copInd}")
	
	String getcopInd();
	
	
}
