package com.bt.ms.im.ngpos.dbclient.entity.dto;

import org.springframework.beans.factory.annotation.Value;

public interface GetDepAgreementIndDto {
	
	@Value("#{target.depositAgreementInd}")

    String getdepositAgreementInd();
}
